"""Run a frozen batch against a streaming chat completions endpoint."""
import argparse
import asyncio
import base64
import hashlib
import json
import os
import statistics
import time
from pathlib import Path

import aiohttp


def prepare(root, group, model, spec):
    ids = json.loads((root / 'batches' / (group + '.json')).read_text())
    records = {r['id']: r for r in map(json.loads, (root / 'requests.jsonl').open())}
    images = {}
    prepared = []
    for rid in ids:
        row = records[rid]
        content = [{'type': 'text', 'text': row['prompt']}]
        for ref in row['images']:
            if ref not in images:
                images[ref] = 'data:image/png;base64,' + base64.b64encode((root / ref).read_bytes()).decode('ascii')
            content.append({'type': 'image_url', 'image_url': {'url': images[ref]}})
        body = dict(model=model, messages=[dict(role='user', content=content)], stream=True,
                    stream_options={'include_usage': True}, temperature=0, ignore_eos=True, max_tokens=4096)
        if spec:
            body['return_spec_tokens_details'] = True
        prepared.append((rid, row['input_tokens'], json.dumps(body, separators=(',', ':')).encode()))
    return prepared


async def run(args):
    root = Path(__file__).resolve().parent
    requests = prepare(root, args.batch, args.model, args.spec_details)
    headers = {'Content-Type': 'application/json'}
    if os.getenv('API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['API_KEY']
    endpoint = args.base_url.rstrip('/') + '/chat/completions'
    async with aiohttp.ClientSession(headers=headers, timeout=aiohttp.ClientTimeout(total=1800),
                                     connector=aiohttp.TCPConnector(limit=len(requests)), trust_env=False) as client:
        async def one(rid, expected, payload):
            start = time.perf_counter()
            first = last = usage = spec = finish = None
            result = {'id': rid, 'expected_input': expected}
            try:
                async with client.post(endpoint, data=payload) as response:
                    if response.status != 200:
                        raise RuntimeError(f'HTTP {response.status}: ' + (await response.text())[:240])
                    async for line in response.content:
                        if not line.startswith(b'data:'):
                            continue
                        data = line[5:].strip()
                        if data == b'[DONE]':
                            break
                        event = json.loads(data)
                        if event.get('error'):
                            raise RuntimeError(str(event['error'])[:240])
                        usage = event.get('usage') or usage
                        spec = (event.get('sglext') or {}).get('spec_tokens_details') or spec
                        for chunk in event.get('choices', []):
                            delta = chunk.get('delta') or {}
                            if first is None and (delta.get('content') or delta.get('reasoning_content') or delta.get('reasoning')):
                                first = time.perf_counter()
                            if chunk.get('finish_reason'):
                                last = time.perf_counter()
                                finish = chunk['finish_reason']
                if first is None or last is None or not usage:
                    raise ValueError('Missing generated content, finish event, or token usage')
                outputs = usage['completion_tokens']
                result.update(input=usage['prompt_tokens'], output=outputs, finish=finish,
                              ttft_s=first-start, tpot_ms=1000*(last-first)/max(1,outputs-1))
                if spec:
                    result['verify_steps'] = spec.get('spec_verify_ct')
                details = usage.get('prompt_tokens_details') or {}
                if 'cached_tokens' in details:
                    result['cached_tokens'] = details['cached_tokens']
                if result['input'] != expected or outputs != 4096:
                    raise ValueError('Token counts differ from the frozen input or output length')
            except Exception as exc:
                result['error'] = str(exc)
            return result

        start = time.perf_counter()
        results = await asyncio.gather(*(one(*item) for item in requests))
        duration = time.perf_counter()-start
    valid = [r for r in results if 'error' not in r]
    report = dict(batch=args.batch, batch_sha256=hashlib.sha256((root/'batches'/(args.batch+'.json')).read_bytes()).hexdigest(),
                  offered_concurrency=len(requests), valid=len(valid)==len(requests), completed=len(valid),
                  duration_s=duration, rows=results)
    if report['valid']:
        outputs = sum(r['output'] for r in valid)
        report.update(output_tps=outputs/duration, mean_ttft_s=statistics.mean(r['ttft_s'] for r in valid),
                      mean_tpot_ms=statistics.mean(r['tpot_ms'] for r in valid))
        if all(r.get('verify_steps') for r in valid):
            report['mtp_accept_length'] = outputs / sum(r['verify_steps'] for r in valid)
    args.out.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'}), flush=True)
    if not report['valid']:
        raise SystemExit(1)


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--base-url', required=True, help='Server API root ending in /v1')
    cli.add_argument('--model', required=True, help='Served model name')
    cli.add_argument('--batch', required=True, choices=[p.stem for p in sorted((Path(__file__).resolve().parent/'batches').glob('*.json'))])
    cli.add_argument('--out', required=True, type=Path, help='Output JSON file')
    cli.add_argument('--spec-details', action='store_true', help='Request SGLang speculative decoding metrics')
    asyncio.run(run(cli.parse_args()))
