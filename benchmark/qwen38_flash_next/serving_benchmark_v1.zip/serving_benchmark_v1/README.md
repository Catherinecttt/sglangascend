# Frozen mixed-input serving benchmark v1

This workload measures serving speed with a fixed mix of long inputs. A, B, C and D each contain 256 distinct requests. Each group has batches of 32, 64, 96, 128, 160, 192, 224 and 256. Every batch is half English text and half English text with images. A larger batch keeps the smaller batch in the same group and adds new requests. The four groups have disjoint requests. Individual pictures can appear more than once.

Each request produces 4,096 output tokens. The mean input of every batch is between 10,000 and 11,000 tokens, including the chat template and image tokens. The longest input is 29,990 tokens. Allow at least 34,086 tokens for input and output together. Use the same model, tokenizer, chat template, image processor and context limit on both machines. In A032 the 16 text inputs average 2,912 tokens and the 16 image inputs average 18,539 tokens. The length target applies to the combined batch. The file fingerprints and per-batch length statistics are in `summary.json`.

## Contents

- `requests.jsonl` contains the request ID, original synthetic prompt, ordered relative paths to pictures and expected input token count. An empty list of pictures denotes a text request.
- `images/` contains geometric drawings with colored backgrounds, a rectangle, an ellipse and their dimensions. The original English text activities cover topics such as toy trains, mosaics and garden observations.
- `batches/A032.json`, for example, lists the 32 request IDs for the first batch in group A, in submission order.

## Run a batch

To check a downloaded archive, place the ZIP and its checksum side by side and run `sha256sum -c serving_benchmark_v1.zip.sha256` before extracting. Run the client from the extracted directory.

Install `aiohttp`. Set `BASE_URL` to the server's API root ending in `/v1` and `MODEL` to its served model name. Set `API_KEY` if authentication is enabled.

```sh
python bench.py --base-url "$BASE_URL" --model "$MODEL" --batch A032 --out result-A032.json
```

The client submits the entire batch concurrently with temperature zero, EOS ignored, streaming enabled and a fixed output length. The endpoint must support these settings. Add `--spec-details` on SGLang to record the aggregate speculative acceptance length if available. E2E is the wall time of the submitted batch. TTFT measures time to first nonempty generated content, including reasoning. TPOT uses the interval from first content to the finish event divided by the remaining output tokens. The client checks the server-reported input count and all 4,096 output tokens for every request.

For a cold-input comparison, warm the service with separate inputs and disable both prefix caching and image embedding caching. Record server concurrency limits, cache settings, parallelism and software versions alongside the result. Run the same group and batch on both systems. Use other groups to check whether a change carries over. The text and images are synthetic; the results characterize this workload.
